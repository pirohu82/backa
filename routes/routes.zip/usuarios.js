const express = require('express');
const router = express.Router();
const { Usuarios } = require('../models');

// Get all usuarios
router.get('/', async (req, res) => {
  const usuarios = await Usuarios.findAll();
  res.json(usuarios);
});

// Create a new usuario
router.post('/', async (req, res) => {
  const usuario = await Usuarios.create(req.body);
  res.json(usuario);
});

// Get a usuario by id
router.get('/:id_usuario', async (req, res) => {
  const usuario = await Usuarios.findByPk(req.params.id_usuario);
  res.json(usuario);
});

// Update a usuario by id
router.put('/:id_usuario', async (req, res) => {
  const usuario = await Usuarios.update(req.body, {
    where: { id_usuario: req.params.id_usuario }
  });
  res.json(usuario);
});

// Delete a usuario by id
router.delete('/:id_usuario', async (req, res) => {
  const usuario = await Usuarios.destroy({
    where: { id_usuario: req.params.id_usuario}
  });
  res.json(usuario);
});

module.exports = router;
